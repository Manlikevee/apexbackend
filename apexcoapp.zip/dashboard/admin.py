from django.contrib import admin

from dashboard.models import Transaction

# Register your models here.

admin.site.register(Transaction)